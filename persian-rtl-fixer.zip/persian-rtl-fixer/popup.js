const applyBtn = document.getElementById("apply");
const status = document.getElementById("status");

const LABEL_OFF = "اعمال تغییر";
const LABEL_ON = "بازگشت به حالت پیش‌فرض";

function render(applied) {
  applyBtn.classList.toggle("is-on", applied);
  applyBtn.textContent = applied ? LABEL_ON : LABEL_OFF;
}

function withActiveTab(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) callback(tabs[0].id);
  });
}

// If the tab was opened/reloaded before this update, content.js is never
// injected, so sendMessage fails silently. Inject it on demand and retry
// once before giving up.
function sendMessage(tabId, message, callback, alreadyRetried) {
  chrome.tabs.sendMessage(tabId, message, (res) => {
    if (chrome.runtime.lastError || !res) {
      if (alreadyRetried) {
        status.textContent = "لطفاً صفحه را رفرش کنید";
        return;
      }
      chrome.scripting.executeScript(
        { target: { tabId }, files: ["content.js"] },
        () => {
          if (chrome.runtime.lastError) {
            status.textContent = "این صفحه پشتیبانی نمی‌شود";
            return;
          }
          sendMessage(tabId, message, callback, true);
        }
      );
      return;
    }
    callback(res);
  });
}

// Sync the button to whatever state this tab is actually in right now,
// in case the popup was closed and reopened after a previous click.
withActiveTab((tabId) => {
  sendMessage(tabId, { type: "GET_STATE" }, (res) => render(res.applied));
});

applyBtn.addEventListener("click", () => {
  withActiveTab((tabId) => {
    sendMessage(tabId, { type: "TOGGLE_STATE" }, (res) => {
      render(res.applied);
      status.textContent = "انجام شد";
      setTimeout(() => (status.textContent = ""), 1500);
    });
  });
});
