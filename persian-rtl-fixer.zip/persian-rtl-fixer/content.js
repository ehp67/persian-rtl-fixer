(function () {
  // Persian / Arabic unicode ranges
  const PERSIAN_ARABIC_REGEX = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
  // Only truly non-content / already-own-paragraph elements are left alone.
  // Note: PRE (multi-line code blocks) is intentionally left LTR as-is.
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "PRE", "TEXTAREA", "INPUT", "SVG"]);
  const BLOCK_SELECTOR =
    "p, div, li, h1, h2, h3, h4, h5, h6, td, th, blockquote, label, dd, dt";
  // Inline "leaf" formatting elements (inline code, bold, italic) are where
  // the bold/code bug lives. Deliberately NOT including span/a here: chat UIs
  // wrap streamed tokens in spans, and unicode-bidi:isolate on those made the
  // whole paragraph's direction detection fail (isolates are opaque to the
  // parent's plaintext first-strong-char scan), flipping entire lines.
  const INLINE_SELECTOR = "code, kbd, b, strong, em, i, mark";

  function hasPersianText(text) {
    return PERSIAN_ARABIC_REGEX.test(text);
  }

  function fixElement(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return;
    if (SKIP_TAGS.has(el.tagName)) return;

    const text = el.innerText || el.textContent || "";
    if (!text.trim()) return;

    if (hasPersianText(text)) {
      // unicode-bidi: plaintext lets the browser pick direction per-paragraph
      // based on the first strong character, which is what fixes the
      // "English word at the start/mid flips the whole line to LTR" bug.
      el.style.setProperty("direction", "rtl", "important");
      el.style.setProperty("unicode-bidi", "plaintext", "important");
      if (el.dataset) el.dataset.rtlFixed = "1";
    }
  }

  function fixInline(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return;
    if (SKIP_TAGS.has(el.tagName)) return;

    const text = el.innerText || el.textContent || "";
    if (!text.trim()) return;

    // unicode-bidi: embed forces this inline run's direction without making
    // it opaque to the parent paragraph's bidi analysis (unlike isolate),
    // so it can't break the surrounding sentence's direction detection.
    const dir = hasPersianText(text) ? "rtl" : "ltr";
    el.style.setProperty("direction", dir, "important");
    el.style.setProperty("unicode-bidi", "embed", "important");
    if (el.dataset) el.dataset.rtlFixed = "1";
  }

  function scan(root) {
    if (!root) return;
    if (root.nodeType === Node.ELEMENT_NODE) {
      fixElement(root);
      root.querySelectorAll(BLOCK_SELECTOR).forEach(fixElement);
      // Inline fixes run last so they win over the broader block styling.
      if (root.matches?.(INLINE_SELECTOR)) fixInline(root);
      root.querySelectorAll(INLINE_SELECTOR).forEach(fixInline);
    }
  }

  function fixParentOf(el) {
    if (!el) return;
    if (el.matches?.(INLINE_SELECTOR)) fixInline(el);
    else fixElement(el);
  }

  let applied = false;
  let observer = null;

  function revertAll() {
    document.querySelectorAll('[data-rtl-fixed="1"]').forEach((el) => {
      el.style.removeProperty("direction");
      el.style.removeProperty("unicode-bidi");
      delete el.dataset.rtlFixed;
    });
  }

  function applyFix() {
    scan(document.body);
    if (!observer) {
      observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
          m.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              scan(node);
            } else if (node.nodeType === Node.TEXT_NODE && node.parentElement) {
              fixParentOf(node.parentElement);
            }
          });
          // Streaming responses grow via text mutations, not new nodes.
          if (m.type === "characterData" && m.target.parentElement) {
            fixParentOf(m.target.parentElement);
          }
        }
      });
    }
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });
    applied = true;
  }

  function disableFix() {
    if (observer) observer.disconnect();
    revertAll();
    applied = false;
  }

  // Popup drives everything through these two messages, toggling between
  // "applied" (auto-fixing, including streamed content) and the page's
  // original, untouched state.
  if (chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "TOGGLE_STATE") {
        if (applied) disableFix();
        else applyFix();
        sendResponse({ applied });
      } else if (msg?.type === "GET_STATE") {
        sendResponse({ applied });
      }
    });
  }
})();
